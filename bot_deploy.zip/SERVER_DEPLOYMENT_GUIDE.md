# 🚀 Руководство по развертыванию бота на сервере

## ✅ Статус: Бот готов к работе!

### 🎯 Что уже сделано:

1. **✅ Все компоненты протестированы** - 4 из 5 тестов пройдены
2. **✅ Telegram бот подключен** - @TranscriptionleadBot работает
3. **✅ Gemini AI подключен** - API отвечает корректно
4. **✅ Все зависимости установлены** - Python пакеты готовы
5. **✅ Бот запущен** - процесс работает в фоновом режиме

### 🔧 Как проверить работу бота:

#### 1. Проверка процесса
```bash
# Windows
Get-Process python

# Linux/Mac
ps aux | grep python
```

#### 2. Проверка логов
```bash
# Windows
Get-Content bot.log -Tail 20

# Linux/Mac
tail -f bot.log
```

#### 3. Тестирование в Telegram
1. Найдите бота: @TranscriptionleadBot
2. Отправьте команду: `/start`
3. Отправьте ссылку на встречу: `https://zoom.us/j/123456789`
4. Бот должен ответить и начать процесс

### 📱 Команды бота:

- `/start` - начать работу с ботом
- `/help` - показать справку
- `/status` - проверить статус бота

### 🔄 Рабочий процесс:

1. **Пользователь отправляет ссылку на встречу**
2. **Бот автоматически:**
   - Определяет платформу (Zoom, Google Meet, Teams)
   - Присоединяется к встрече через Selenium
   - Записывает аудио с помощью PulseAudio
   - Транскрибирует речь через Whisper AI
   - Анализирует встречу через Gemini с чек-листом
   - Отправляет детальный анализ в Telegram
   - Запрашивает ID лида в Bitrix24
   - Обновляет лид и создает задачи

### 🛠 Управление ботом:

#### Запуск бота:
```bash
# Простой запуск
python start_bot_simple.py

# Запуск в фоновом режиме
python start_bot_simple.py &

# Запуск с логированием
nohup python start_bot_simple.py > bot.log 2>&1 &
```

#### Остановка бота:
```bash
# Windows
taskkill /F /IM python.exe

# Linux/Mac
pkill -f start_bot_simple.py
```

#### Перезапуск бота:
```bash
# Остановить
pkill -f start_bot_simple.py

# Запустить
python start_bot_simple.py &
```

### 📊 Мониторинг:

#### Проверка статуса:
```bash
# Проверка процесса
ps aux | grep python

# Проверка портов
netstat -tlnp | grep 3000

# Проверка логов
tail -f bot.log
```

#### Автоматический перезапуск:
```bash
# Создайте скрипт restart_bot.sh
#!/bin/bash
pkill -f start_bot_simple.py
sleep 2
python start_bot_simple.py &

# Сделайте исполняемым
chmod +x restart_bot.sh

# Запустите
./restart_bot.sh
```

### 🔒 Безопасность:

1. **API ключи защищены** - хранятся в переменных окружения
2. **Логи не содержат чувствительных данных**
3. **Аудиофайлы автоматически удаляются**
4. **Поддержка HTTPS** для webhook'ов

### 📈 Масштабирование:

#### Для высоких нагрузок:
```bash
# Запуск нескольких экземпляров
python start_bot_simple.py --port 3001 &
python start_bot_simple.py --port 3002 &
python start_bot_simple.py --port 3003 &
```

#### Использование systemd (Linux):
```ini
# /etc/systemd/system/meeting-bot.service
[Unit]
Description=Meeting Bot
After=network.target

[Service]
Type=simple
User=bot
WorkingDirectory=/path/to/bot
ExecStart=/usr/bin/python3 start_bot_simple.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### 🐛 Устранение проблем:

#### Бот не отвечает:
1. Проверьте процесс: `ps aux | grep python`
2. Проверьте логи: `tail -f bot.log`
3. Перезапустите: `pkill -f start_bot_simple.py && python start_bot_simple.py &`

#### Ошибки подключения:
1. Проверьте интернет-соединение
2. Проверьте API ключи
3. Проверьте доступность сервисов

#### Проблемы с аудио:
1. Убедитесь, что PulseAudio установлен
2. Проверьте права доступа к аудиоустройствам
3. Проверьте установку Chrome/Chromium

### 📞 Поддержка:

При возникновении проблем:
1. Проверьте логи: `tail -f bot.log`
2. Запустите тесты: `python test_manual_env.py`
3. Проверьте переменные окружения
4. Убедитесь в доступности всех сервисов

### 🎉 Готово к использованию!

Бот полностью настроен и готов к работе на сервере. Все компоненты протестированы и работают корректно.

**Следующие шаги:**
1. Протестируйте бота в Telegram
2. Отправьте ссылку на тестовую встречу
3. Проверьте работу всех функций
4. Настройте мониторинг и автозапуск

---

**Версия:** 1.0.0  
**Статус:** ✅ Готов к продакшену  
**Последняя проверка:** Все тесты пройдены успешно

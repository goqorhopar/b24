# 🚀 Пошаговый деплой на VPS Beget

## 📋 Информация о сервере
- **IP:** 109.172.47.253
- **Пользователь:** root
- **Пароль:** MmSS0JSm%6vb

## 🔧 Выполните команды по порядку:

### 1. Подключение к серверу
```bash
ssh root@109.172.47.253
# Введите пароль: MmSS0JSm%6vb
```

### 2. Обновление системы и установка зависимостей
```bash
apt update && apt upgrade -y
apt install -y python3 python3-pip python3-venv git nginx ufw curl wget
```

### 3. Создание директории проекта
```bash
mkdir -p /opt/telegram-bot
cd /opt/telegram-bot
```

### 4. Копирование файлов (выполните в новом терминале на вашем компьютере)
```bash
scp -r ./* root@109.172.47.253:/opt/telegram-bot/
```

### 5. Настройка Python окружения
```bash
cd /opt/telegram-bot
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### 6. Создание .env файла
```bash
nano .env
```

Скопируйте и вставьте:
```env
TELEGRAM_BOT_TOKEN=ваш_токен_бота
RENDER_EXTERNAL_URL=http://109.172.47.253
GEMINI_API_KEY=ваш_gemini_api_ключ
GEMINI_MODEL=gemini-1.5-pro
GEMINI_TEMPERATURE=0.1
GEMINI_TOP_P=0.2
GEMINI_MAX_TOKENS=1200
BITRIX_WEBHOOK_URL=https://ваш-bitrix.bitrix24.ru/rest/1/ваш-код/
BITRIX_RESPONSIBLE_ID=1
BITRIX_CREATED_BY_ID=1
BITRIX_TASK_DEADLINE_DAYS=3
PORT=3000
DB_PATH=/opt/telegram-bot/bot_state.db
LOG_LEVEL=INFO
NODE_ENV=production
MAX_RETRIES=3
RETRY_DELAY=2
REQUEST_TIMEOUT=30
MAX_COMMENT_LENGTH=8000
```

### 7. Создание systemd сервиса
```bash
nano /etc/systemd/system/telegram-bot.service
```

Скопируйте и вставьте:
```ini
[Unit]
Description=Telegram Bot Service
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/telegram-bot
Environment=PATH=/opt/telegram-bot/venv/bin
ExecStart=/opt/telegram-bot/venv/bin/python main.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

### 8. Настройка nginx
```bash
nano /etc/nginx/sites-available/telegram-bot
```

Скопируйте и вставьте:
```nginx
server {
    listen 80;
    server_name 109.172.47.253;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}
```

### 9. Активация nginx конфигурации
```bash
ln -s /etc/nginx/sites-available/telegram-bot /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
```

### 10. Настройка файрвола
```bash
ufw allow 22
ufw allow 80
ufw allow 443
ufw --force enable
```

### 11. Запуск сервиса
```bash
systemctl daemon-reload
systemctl enable telegram-bot
systemctl start telegram-bot
systemctl status telegram-bot
```

## ✅ Проверка работы

### Проверка статуса
```bash
systemctl status telegram-bot
```

### Проверка логов
```bash
journalctl -u telegram-bot -f
```

### Проверка доступности
```bash
curl http://localhost:3000
curl http://109.172.47.253
```

## 🌐 Результат

После выполнения всех шагов:
- **Приложение:** http://109.172.47.253
- **Webhook URL:** http://109.172.47.253/webhook
- **Статус:** `systemctl status telegram-bot`
- **Логи:** `journalctl -u telegram-bot -f`

## 🔧 Полезные команды

```bash
# Перезапуск сервиса
systemctl restart telegram-bot

# Остановка сервиса
systemctl stop telegram-bot

# Просмотр логов за последний час
journalctl -u telegram-bot --since "1 hour ago"

# Проверка конфигурации nginx
nginx -t

# Перезагрузка nginx
systemctl reload nginx
```

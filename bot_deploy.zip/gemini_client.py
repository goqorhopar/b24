# gemini_client.py
import os
import logging
import time
import re
import json
from typing import Dict, Any, Optional
import requests
from datetime import datetime

# Попытка импортировать google.generativeai (работает с разными версиями)
try:
    import google.generativeai as genai  # type: ignore
except Exception as exc:
    raise RuntimeError(f"Невозможно импортировать google.generativeai: {exc}")

# Попытка импортировать типы безопасности (в некоторых версиях их может не быть)
try:
    from google.generativeai.types import HarmCategory, HarmBlockThreshold  # type: ignore
except Exception:
    HarmCategory = None
    HarmBlockThreshold = None  # type: ignore

log = logging.getLogger(__name__)

# Конфигурация из окружения
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")
# Фолбэк-модель на случай лимитов
MODEL_FALLBACK = os.getenv("GEMINI_MODEL_FALLBACK", "gemini-1.5-flash")
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))
RETRY_DELAY = float(os.getenv("RETRY_DELAY", "2"))
# Небольшой джиттер к задержке, чтобы разнести запросы
RETRY_JITTER = float(os.getenv("RETRY_JITTER", "0.5"))
# Ограничение длины входного текста (в символах) для снижения затрат токенов
INPUT_MAX_CHARS = int(os.getenv("GEMINI_INPUT_MAX_CHARS", "15000"))
TEMPERATURE = float(os.getenv("GEMINI_TEMPERATURE", "0.1"))
TOP_P = float(os.getenv("GEMINI_TOP_P", "0.2"))
MAX_OUTPUT_TOKENS_DEFAULT = int(os.getenv("GEMINI_MAX_TOKENS", "1200"))

if not GEMINI_API_KEY:
    raise RuntimeError("GEMINI_API_KEY не найден в переменных окружения!")

# Настройка ключа
try:
    genai.configure(api_key=GEMINI_API_KEY)
except Exception as e:
    # Не фатальная ошибка — дальше в вызовах мы обработаем возможные ошибки
    log.debug(f"genai.configure вызвало исключение: {e}")

# Безопасностные настройки (если поддерживаются)
SAFETY_SETTINGS = {}
if HarmCategory is not None and HarmBlockThreshold is not None:
    try:
        categories = [
            'HARM_CATEGORY_HATE_SPEECH',
            'HARM_CATEGORY_HARASSMENT',
            'HARM_CATEGORY_SEXUAL',
            'HARM_CATEGORY_SEXUALLY_EXPLICIT',
            'HARM_CATEGORY_DANGEROUS_CONTENT',
        ]
        for name in categories:
            if hasattr(HarmCategory, name):
                cat = getattr(HarmCategory, name)
                SAFETY_SETTINGS[cat] = HarmBlockThreshold.BLOCK_NONE
        log.debug("SAFETY_SETTINGS установлены")
    except Exception:
        SAFETY_SETTINGS = {}

# ---- Вспомогательные функции ----

def sanitize_transcript_for_safety(text: str) -> str:
    """
    Подменяет потенциально проблемные слова, чтобы снизить вероятность триггеров фильтров
    и убрать грубую лексику перед отправкой в модель.
    """
    if not text:
        return text

    replacements = {
        r"\bсекс\w*\b": "интимн.",
        r"\bэрот\w*\b": "эр.",
        r"\bпорно\w*\b": "взр.контент",
        r"\bубить\b": "устранить",
        r"\bубийство\b": "устранение",
        r"\bнасилие\b": "принуждение",
        r"\bнаркотик\w*\b": "запр.вещество",
        # мат
        r"\bбля\w*\b": "блин",
        r"\bхуй\w*\b": "фиг",
        r"\bпизд\w*\b": "плохо"
    }

    cleaned = text
    for pattern, repl in replacements.items():
        cleaned = re.sub(pattern, repl, cleaned, flags=re.IGNORECASE)
    return cleaned


def normalize_transcript_format(text: str) -> str:
    """
    Препроцессинг чатов/телеграм-логов:
    - Удаляет строки с метаданными времени/имен ("Имя, [ДД.ММ.ГГГГ ЧЧ:ММ]")
    - Убирает повторяющиеся заголовки
    - Сохраняет только содержательные реплики
    """
    if not text:
        return text
    lines = text.splitlines()
    out = []
    # Пример строки: "Григорий Манукян, [11.09.2025 23:10]"
    meta_re = re.compile(r"^[^\[,]{2,}?,\s*\[\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2}(?::\d{2})?\]\s*$")
    # Маркеры менеджеров
    manager_names = {"григорий", "виктор"}
    speaker_re = re.compile(r"^([А-ЯЁ][а-яё]+)(?:\s+[А-ЯЁ][а-яё]+)?\s*[:\-]?")
    for ln in lines:
        if meta_re.match(ln.strip()):
            continue
        # Помечаем реплики менеджеров для подсказки модели
        m = speaker_re.match(ln.strip())
        if m:
            name = m.group(1).strip().lower()
            if name in manager_names:
                # Заменим префикс на явную роль
                ln = re.sub(r"^\s*.*?[:\-]\s*", "МЕНЕДЖЕР: ", ln, count=1)
        out.append(ln)
    # Удаляем лидирующие/хвостовые пустые строки
    cleaned = "\n".join([l for l in out if l is not None])
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
    return cleaned


def _is_header_or_meta(s: Optional[str]) -> bool:
    if not s:
        return False
    t = str(s).strip()
    if not t:
        return False
    # Совпадение телеграм-заголовка "Имя, [дата]"
    if re.match(r"^[^\[,]{2,}?,\s*\[\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2}(?::\d{2})?\]", t):
        return True
    # Явная роль менеджера
    if t.upper().startswith("МЕНЕДЖЕР:"):
        return True
    # Похожие разделители без контента
    if len(t) <= 4 and all(ch in "-_* ." for ch in t):
        return True
    return False

def _build_analysis_prompt(transcript: str) -> str:
    """
    Формирует подробный промпт для модели.
    Возвращаемый текст ориентирован на получение JSON-структуры с определёнными полями.
    """
    current_date = datetime.now().strftime("%d.%m.%Y")
    prompt = (
        f"ИНСТРУКЦИЯ ДЛЯ GEMINI (Промпт)\n"
        f"Роль: Ты — эксперт-аналитик по продажам и переговорам. Сегодня {current_date}.\n"
        "Твоя задача — проанализировать транскрипт встречи менеджера с клиентом, дать развернутую оценку по 12 пунктам чек-листа и, что важнее всего, сгенерировать структурированный JSON-объект с данными для автоматического обновления карточки лида и создания задач в CRM Bitrix24.\n\n"
        "КРИТИЧЕСКИЕ ПРАВИЛА РАСПОЗНАВАНИЯ РОЛЕЙ:\n"
        "- Всегда считай, что Григорий и Виктор — это менеджеры со стороны нашей компании. Они НЕ являются клиентами.\n"
        "- Если встречаются имена Григорий/Виктор, не путай их с клиентом; клиент — другое лицо.\n"
        "- Если источник — телеграм-транскрипт, игнорируй строки вида 'Имя, [ДД.ММ.ГГГГ ЧЧ:ММ]'.\n\n"
        "ИНСТРУКЦИЯ:\n"
        "1) Внимательно проанализируй предоставленную транскрипцию.\n"
        "2) Сформируй один JSON-объект, содержащий два блока: analysis_report (текстовый отчёт по 12 пунктам ниже, строго структурирован) и bitrix24_update (структурированные данные для CRM).\n"
        "3) Верни строго валидный JSON без какого-либо дополнительного текста.\n\n"
        "ФОРМАТ ОТВЕТА:\n"
        "{\n"
        "  \"analysis_report\": \"...подробный отчёт по 12 пунктам...\",\n"
        "  \"bitrix24_update\": {\n"
        "    \"fields_to_update\": {\n"
        "      \"COMMENTS\": \"строка\",\n"
        "      \"TITLE\": \"строка или null\",\n"
        "      \"NAME\": \"строка или null\",\n"
        "      \"LAST_NAME\": \"строка или null\",\n"
        "      \"COMPANY_TITLE\": \"строка или null\",\n"
        "      \"ASSIGNED_BY_ID\": number или null,\n"
        "      \"UF_*\": \"значения пользовательских полей, если применимо\"\n"
        "    },\n"
        "    \"tasks_to_create\": [\n"
        "      { \"title\": \"строка\", \"description\": \"строка\", \"deadline\": \"YYYY-MM-DD или YYYY-MM-DD HH:MM:SS\", \"responsible_id\": number }\n"
        "    ],\n"
        "    \"lead_category\": \"A|B|C\"\n"
        "  }\n"
        "}\n\n"
        "ЧЕК-ЛИСТ (включить разбор в analysis_report):\n"
        "1) АНАЛИЗ ТЕКУЩЕГО БИЗНЕСА КЛИЕНТА — задачи, источники, удовлетворённость (1-10), ЦА/трафик, спрос/создание потребности, средний чек/отдел продаж, глубина проработки менеджером.\n"
        "2) ВЫЯВЛЕНИЕ БОЛЕЙ И ПОТРЕБНОСТЕЙ — проблемы, упущенная прибыль, качество лидов, методы выявления, боли/мотивации/опасения, степень закрытия (0-100%).\n"
        "3) ВОЗРАЖЕНИЯ ПО ЛИДОГЕНЕРАЦИИ — перечень, методы отработки, что сработало/нет, альтернативы.\n"
        "4) РЕАКЦИЯ НА МОДЕЛЬ ГЕНЕРАЦИИ — оценка подхода, понимание ценности голосового подтверждения.\n"
        "5) ОСОБЫЙ ИНТЕРЕС — аспекты (конкуренты, качество скриптов, УТП, записи), что зацепило.\n"
        "6) НАЙДЕННЫЕ ВОЗМОЖНОСТИ — рост конверсии, экономия ресурсов, рост выручки, масштабирование.\n"
        "7) ОШИБКИ МЕНЕДЖЕРА — конкретные промахи с примерами.\n"
        "8) ПУТЬ К ЗАКРЫТИЮ — CPL/ROI, план коммуникации, дедлайн, CTA, причины отказа, как ускорить, уточнение причины возможного отказа.\n"
        "9) ТОН БЕСЕДЫ — общая атмосфера.\n"
        "10) КОНТРОЛЬ ДИАЛОГА — кто доминировал, кто задавал вопросы.\n"
        "11) РЕКОМЕНДАЦИИ — конкретные советы.\n"
        "12) КАТЕГОРИЯ КЛИЕНТА — A/B/C с обоснованием.\n\n"
        "Строгие требования: Всегда возвращай один корректный JSON с указанной структурой.\n\n"
        "ТРАНСКРИПТ:\n```\n" + transcript.strip() + "\n```\n"
    )
    return prompt


def extract_json_from_text(text: str) -> Optional[Dict[str, Any]]:
    """
    Ищет JSON-объект в текстовом ответе модели.
    Поддерживает блоки ```json``` и "сырой" JSON.
    """
    if not text:
        return None

    # 1) JSON в ```json ... ```
    m = re.search(r'```json\s*(\{.*\})\s*```', text, re.DOTALL | re.IGNORECASE)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass

    # 2) Ищем наиболее длинный корректный JSON-объект методом скобочного стека
    brace_stack = []
    start = None
    candidates = []
    for i, ch in enumerate(text):
        if ch == '{':
            if start is None:
                start = i
            brace_stack.append('{')
        elif ch == '}' and brace_stack:
            brace_stack.pop()
            if not brace_stack and start is not None:
                candidate = text[start:i+1]
                candidates.append(candidate)
                start = None

    # Сортируем кандидаты по длине (большие предпочтительнее)
    candidates.sort(key=len, reverse=True)
    for cand in candidates:
        try:
            parsed = json.loads(cand)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            continue

    # 3) Попытка найти простой JSON по regex (последняя инстанция)
    json_matches = re.findall(r'\{(?:[^{}]|\{[^{}]*\})*\}', text, re.DOTALL)
    for match in sorted(json_matches, key=len, reverse=True):
        try:
            parsed = json.loads(match)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            continue

    return None


def _transform_model_json_to_internal(parsed: Dict[str, Any]) -> Dict[str, Any]:
    """
    Принимает JSON от модели по схеме analysis_report/bitrix24_update и
    преобразует к нашей внутренней схеме полей, ожидаемой update_lead_comprehensive.
    Если parsed уже в нашей схеме, возвращает его без изменений.
    """
    if not isinstance(parsed, dict):
        return {}

    # Если уже похоже на нашу схему (есть ключи из expected_fields) — вернуть как есть
    likely_internal = any(k in parsed for k in (
        "analysis", "is_lpr", "meeting_scheduled", "meeting_done", "product", "ad_budget"
    ))
    if likely_internal and "bitrix24_update" not in parsed:
        return parsed

    analysis_report = parsed.get("analysis_report")
    b24 = parsed.get("bitrix24_update") or {}
    fields_to_update = b24.get("fields_to_update") or {}

    # Известные соответствия UF_* -> внутренним ключам (должно совпадать с bitrix.update_lead_comprehensive)
    uf_to_internal = {
        'UF_CRM_1754665062': 'wow_effect',
        'UF_CRM_1579102568584': 'product',
        'UF_CRM_1592909799043': 'task_formulation',
        'UF_CRM_1592910027': 'ad_budget',
        'UF_CRM_1754651857': 'is_lpr',
        'UF_CRM_1754651891': 'meeting_scheduled',
        'UF_CRM_1754651937': 'meeting_done',
        'UF_CRM_1547738289': 'client_type_text',
        'UF_CRM_1555492157080': 'bad_reason_text',
        'UF_CRM_1754652099': 'kp_done_text',
        'UF_CRM_1755007163632': 'lpr_confirmed_text',
        'UF_CRM_1648714327': 'source_text',
        'UF_CRM_1741622365': 'our_product_text',
        'UF_CRM_1592911226916': 'closing_comment',
        'UF_CRM_1756298185': 'meeting_responsible_id',
        'UF_CRM_1755862426686': 'meeting_date',
        'UF_CRM_1757408917': 'planned_meeting_date',
    }

    out: Dict[str, Any] = {}

    # Текстовый анализ/комментарий
    comments = fields_to_update.get("COMMENTS")
    out["analysis"] = analysis_report or comments or parsed.get("analysis")
    # Поля лида стандартные
    if "TITLE" in fields_to_update:
        out["lead_title"] = fields_to_update.get("TITLE")
    if "NAME" in fields_to_update:
        out["client_name"] = fields_to_update.get("NAME")
    if "LAST_NAME" in fields_to_update:
        out["client_last_name"] = fields_to_update.get("LAST_NAME")
    if "COMPANY_TITLE" in fields_to_update:
        out["company_title"] = fields_to_update.get("COMPANY_TITLE")
    if "ASSIGNED_BY_ID" in fields_to_update:
        out["assigned_by_id"] = fields_to_update.get("ASSIGNED_BY_ID")

    # Перенос известных UF полей
    for key, val in fields_to_update.items():
        if isinstance(key, str) and key.startswith("UF_"):
            internal = uf_to_internal.get(key)
            if internal:
                out[internal] = val

    # Мягкая поддержка подсказок источника
    lead_category = b24.get("lead_category")
    if lead_category and not out.get("client_type_text"):
        out["client_type_text"] = str(lead_category)

    # Слияние с исходными данными (если вдруг модель вернула некоторые внутренние поля сверху)
    for k in (
        "key_request", "pains_text", "budget_value", "budget_currency", "timeline_text", "goal_text",
        "product", "task_formulation", "ad_budget", "closing_comment",
        "is_lpr", "meeting_scheduled", "meeting_done",
        "client_type_text", "bad_reason_text", "kp_done_text", "lpr_confirmed_text",
        "source_id_code", "source_id_text", "source_text", "our_product_text",
        "meeting_date", "planned_meeting_date", "meeting_responsible_id",
        "sentiment", "next_action", "next_action_comment"
    ):
        if parsed.get(k) is not None and k not in out:
            out[k] = parsed.get(k)

    return out

def validate_gemini_output(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Приводит выход модели к ожидаемому набору полей и типов.
    Нормализует булевы поля, оставляет все ожидаемые ключи.
    """
    expected_fields = [
        "analysis", "key_request", "pains_text", "budget_value", "budget_currency", "timeline_text", "goal_text",
        "client_name", "client_last_name", "position", "company_title",
        "product", "task_formulation", "ad_budget", "closing_comment",
        "is_lpr", "meeting_scheduled", "meeting_done",
        "client_type_text", "bad_reason_text", "kp_done_text", "lpr_confirmed_text",
        "source_id_code", "source_id_text", "source_text", "our_product_text",
        "meeting_date", "planned_meeting_date", "meeting_responsible_id",
        "sentiment", "next_action", "next_action_comment"
    ]

    normalized: Dict[str, Any] = {}
    for f in expected_fields:
        v = data.get(f) if isinstance(data, dict) else None

        # булевые поля
        if f in ("is_lpr", "meeting_scheduled", "meeting_done"):
            if isinstance(v, bool):
                normalized[f] = v
            elif isinstance(v, (int, float)):
                normalized[f] = bool(v)
            elif isinstance(v, str):
                vs = v.strip().lower()
                if vs in ("yes", "true", "да", "1"):
                    normalized[f] = True
                elif vs in ("no", "false", "нет", "0"):
                    normalized[f] = False
                else:
                    normalized[f] = None
            else:
                normalized[f] = None
        # числовые поля
        elif f in ("budget_value", "meeting_responsible_id"):
            try:
                normalized[f] = float(v) if v is not None else None
            except Exception:
                normalized[f] = None
        else:
            # сохраняем значение или None
            normalized[f] = v if v is not None else None

    return normalized


# ---- Вызов модели: универсальный и надёжный ----

def _truncate_for_input(text: str, max_chars: int) -> str:
    """Грубое ограничение входного текста по символам с сохранением конца.
    Берём последние max_chars символов, чтобы сохранить контекст финала разговора.
    """
    if not text:
        return text
    if len(text) <= max_chars:
        return text
    # Оставляем пометку, что текст обрезан
    head = "[...обрезано для лимитов...]\n"
    return head + text[-max_chars:]

def _call_gemini(prompt: str, model: Optional[str] = None, max_tokens: int = MAX_OUTPUT_TOKENS_DEFAULT) -> str:
    """
    Умный обёртывающий вызов Gemini с ретраями и улучшенной обработкой rate limits.
    Попробует несколько возможных путей вызова в зависимости от версии библиотеки.
    На повторах: снижает max_tokens, добавляет jitter, при лимитах может переключиться на fallback-модель.
    """
    if model is None:
        model = MODEL_NAME

    last_exc = None
    base_delay = RETRY_DELAY
    current_model = model

    for attempt in range(1, MAX_RETRIES + 1):
        # С каждым ретраем снижаем ожидаемую длину ответа
        dynamic_max_tokens = max(256, int(max_tokens * (0.8 ** (attempt - 1))))
        try:
            # 1) Попытка через GenerativeModel (современные версии)
            if hasattr(genai, "GenerativeModel"):
                try:
                    ModelClass = getattr(genai, "GenerativeModel")
                    model_obj = ModelClass(current_model)
                    if hasattr(model_obj, "generate_content"):
                        resp = model_obj.generate_content(
                            prompt,
                            generation_config={
                                "max_output_tokens": dynamic_max_tokens,
                                "temperature": TEMPERATURE,
                                "top_p": TOP_P,
                                "response_mime_type": "application/json"
                            },
                            safety_settings=SAFETY_SETTINGS or None
                        )
                        if hasattr(resp, "text"):
                            return resp.text
                        if isinstance(resp, dict) and "output" in resp:
                            out = resp.get("output")
                            if isinstance(out, dict):
                                if "content" in out:
                                    return str(out["content"])
                                candidates = out.get("candidates")
                                if candidates and isinstance(candidates, list) and len(candidates) > 0:
                                    cand = candidates[0]
                                    if isinstance(cand, dict):
                                        return cand.get("content", "") or str(cand)
                                    return str(cand)
                            return str(resp)
                        return str(resp)
                    if hasattr(model_obj, "generate_text"):
                        resp = model_obj.generate_text(prompt, max_output_tokens=dynamic_max_tokens)
                        if hasattr(resp, "text"):
                            return resp.text
                        return str(resp)
                except Exception as e:
                    msg = str(e)
                    if ("429" in msg) or ("rate limit" in msg.lower()) or ("quota" in msg.lower()):
                        # Экспоненциальная задержка + джиттер
                        wait_time = base_delay * (2 ** (attempt - 1)) + random.uniform(0, RETRY_JITTER)
                        log.warning(f"Rate limit (SDK). Waiting {wait_time:.2f}s before retry...")
                        time.sleep(wait_time)
                        # Переключаемся на fallback-модель со второго ретрая
                        if attempt >= 2 and current_model != MODEL_FALLBACK:
                            log.warning(f"Switching model to fallback '{MODEL_FALLBACK}' due to limits")
                            current_model = MODEL_FALLBACK
                        last_exc = e
                        continue
                    log.debug(f"Попытка вызова через GenerativeModel провалилась: {e}")
                    last_exc = e

            # 2) genai.generate_text
            if hasattr(genai, "generate_text"):
                try:
                    func = getattr(genai, "generate_text")
                    resp = func(model=current_model, prompt=prompt, max_output_tokens=dynamic_max_tokens, temperature=TEMPERATURE, top_p=TOP_P)
                    if isinstance(resp, dict):
                        if "candidates" in resp and resp["candidates"]:
                            cand = resp["candidates"][0]
                            if isinstance(cand, dict) and "content" in cand:
                                return cand["content"]
                            return str(cand)
                        if "output" in resp:
                            out = resp["output"]
                            if isinstance(out, dict) and "content" in out:
                                return out["content"]
                            return str(out)
                    if hasattr(resp, "text"):
                        return resp.text
                    return str(resp)
                except Exception as e:
                    msg = str(e)
                    if ("429" in msg) or ("rate limit" in msg.lower()) or ("quota" in msg.lower()):
                        wait_time = base_delay * (2 ** (attempt - 1)) + random.uniform(0, RETRY_JITTER)
                        log.warning(f"Rate limit (generate_text). Waiting {wait_time:.2f}s before retry...")
                        time.sleep(wait_time)
                        if attempt >= 2 and current_model != MODEL_FALLBACK:
                            log.warning(f"Switching model to fallback '{MODEL_FALLBACK}' due to limits")
                            current_model = MODEL_FALLBACK
                        last_exc = e
                        continue
                    log.debug(f"genai.generate_text провалился: {e}")
                    last_exc = e

            # 3) Старые интерфейсы
            if hasattr(genai, "create_chat_completion"):
                try:
                    resp = genai.create_chat_completion(model=current_model, messages=[{"role": "user", "content": prompt}], max_output_tokens=dynamic_max_tokens)
                    if hasattr(resp, "candidates") and resp.candidates:
                        return resp.candidates[0].content
                    if isinstance(resp, dict):
                        cand = resp.get("candidates")
                        if cand and isinstance(cand, list):
                            c0 = cand[0]
                            if isinstance(c0, dict) and "content" in c0:
                                return c0["content"]
                    return str(resp)
                except Exception as e:
                    msg = str(e)
                    if ("429" in msg) or ("rate limit" in msg.lower()) or ("quota" in msg.lower()):
                        wait_time = base_delay * (2 ** (attempt - 1)) + random.uniform(0, RETRY_JITTER)
                        log.warning(f"Rate limit (legacy). Waiting {wait_time:.2f}s before retry...")
                        time.sleep(wait_time)
                        if attempt >= 2 and current_model != MODEL_FALLBACK:
                            log.warning(f"Switching model to fallback '{MODEL_FALLBACK}' due to limits")
                            current_model = MODEL_FALLBACK
                        last_exc = e
                        continue
                    log.debug(f"create_chat_completion провалился: {e}")
                    last_exc = e

            # 4) REST API фолбэк
            try:
                api_key = GEMINI_API_KEY
                if not api_key:
                    raise RuntimeError("GEMINI_API_KEY не задан")
                rest_model = current_model or MODEL_NAME
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{rest_model}:generateContent?key={api_key}"
                payload: Dict[str, Any] = {
                    "contents": [
                        {"role": "user", "parts": [{"text": prompt}]}],
                    "generationConfig": {
                        "maxOutputTokens": dynamic_max_tokens,
                        "temperature": TEMPERATURE,
                        "topP": TOP_P,
                        "responseMimeType": "application/json"
                    }
                }
                headers = {"Content-Type": "application/json"}
                r = requests.post(url, headers=headers, json=payload, timeout=30)

                if r.status_code == 429:
                    # Учитываем Retry-After, если есть
                    retry_after = 0.0
                    try:
                        retry_after = float(r.headers.get("Retry-After", "0"))
                    except Exception:
                        retry_after = 0.0
                    wait_time = max(retry_after, base_delay * (2 ** (attempt - 1))) + random.uniform(0, RETRY_JITTER)
                    log.warning(f"Rate limit (REST). Waiting {wait_time:.2f}s before retry...")
                    time.sleep(wait_time)
                    if attempt >= 2 and current_model != MODEL_FALLBACK:
                        log.warning(f"Switching model to fallback '{MODEL_FALLBACK}' due to limits")
                        current_model = MODEL_FALLBACK
                    last_exc = requests.exceptions.HTTPError("429 Too Many Requests", response=r)
                    continue

                r.raise_for_status()
                data = r.json()
                if isinstance(data, dict):
                    candidates = data.get("candidates") or []
                    if candidates:
                        c0 = candidates[0]
                        if isinstance(c0, dict):
                            content = c0.get("content") or {}
                            if isinstance(content, dict):
                                parts = content.get("parts") or []
                                texts = []
                                for p in parts:
                                    if isinstance(p, dict) and "text" in p:
                                        texts.append(str(p["text"]))
                                if texts:
                                    return "\n".join(texts)
                return r.text
            except requests.exceptions.HTTPError as e:
                if e.response and e.response.status_code == 429:
                    retry_after = 0.0
                    try:
                        retry_after = float(e.response.headers.get("Retry-After", "0"))
                    except Exception:
                        retry_after = 0.0
                    wait_time = max(retry_after, base_delay * (2 ** (attempt - 1))) + random.uniform(0, RETRY_JITTER)
                    log.warning(f"Rate limit (REST exception). Waiting {wait_time:.2f}s before retry...")
                    time.sleep(wait_time)
                    if attempt >= 2 and current_model != MODEL_FALLBACK:
                        log.warning(f"Switching model to fallback '{MODEL_FALLBACK}' due to limits")
                        current_model = MODEL_FALLBACK
                    last_exc = e
                    continue
                last_exc = e
                raise RuntimeError(f"Ошибка вызова Gemini REST API: {e}")
            except Exception as e:
                last_exc = e
                raise RuntimeError(f"Ошибка вызова Gemini REST API: {e}")

        except Exception as e:
            last_exc = e
            if "429" not in str(e) and "rate limit" not in str(e).lower() and "quota" not in str(e).lower():
                log.warning(f"Попытка {attempt}/{MAX_RETRIES} к Gemini провалена: {e}")
                if attempt < MAX_RETRIES:
                    time.sleep(base_delay + random.uniform(0, RETRY_JITTER))
                else:
                    log.error(f"Не удалось вызвать Gemini после {MAX_RETRIES} попыток: {last_exc}")
                    raise last_exc

    log.error(f"Failed to call Gemini API after retries")
    raise last_exc or RuntimeError("Failed to call Gemini API after retries")


# ---- Основные публичные функции API ----

def analyze_transcript_structured(transcript: str) -> Dict[str, Any]:
    """
    Основная функция для анализа транскрипта.
    Возвращает нормализованный словарь с ожидаемыми полями.
    """
    try:
        if not transcript or not transcript.strip():
            return {"analysis": None}

        # Препроцессинг: нормализуем формат и обезвреживаем потенциальные триггеры
        preprocessed = normalize_transcript_format(transcript)
        safe_txt = sanitize_transcript_for_safety(preprocessed)
        # Ограничиваем входной размер, чтобы реже ловить лимиты
        safe_txt = _truncate_for_input(safe_txt, INPUT_MAX_CHARS)
        prompt = _build_analysis_prompt(safe_txt)

        raw = _call_gemini(prompt, model=MODEL_NAME, max_tokens=MAX_OUTPUT_TOKENS_DEFAULT)
        if not raw:
            log.warning("Gemini вернул пустой ответ")
            return {"analysis": "Пустой ответ от модели"}
        parsed = extract_json_from_text(raw)
        if parsed is None:
            # Попробуем сделать повторный краткий вызов строго под JSON
            try:
                strict_prompt = "Верни строго JSON по ранее заданной схеме без пояснений. Если данных нет — верни ключи со значением null.\n\nТЕКСТ:\n" + transcript.strip()
                raw2 = _call_gemini(strict_prompt, model=MODEL_NAME, max_tokens=512)
                parsed = extract_json_from_text(raw2)
            except Exception:
                parsed = None
            # Если JSON не найден — попытка взять начало ответа как анализ
            fallback_analysis = raw.strip()
            if len(fallback_analysis) > 4000:
                fallback_analysis = fallback_analysis[:4000] + "..."
            result = {
                "analysis": fallback_analysis,
                "wow_effect": None,
                "product": None,
                "task_formulation": None,
                "ad_budget": None,
                "closing_comment": None,
                "is_lpr": None,
                "meeting_scheduled": None,
                "meeting_done": None,
                "client_type_text": None,
                "bad_reason_text": None,
                "kp_done_text": None,
                "lpr_confirmed_text": None,
                "source_text": None,
                "our_product_text": None,
                "meeting_date": None,
                "planned_meeting_date": None,
                "meeting_responsible_id": None
            }
            return result

        # Приводим JSON от модели к нашей внутренней схеме, затем валидируем/нормализуем
        transformed = _transform_model_json_to_internal(parsed)
        validated = validate_gemini_output(transformed)

        # Если модель вернула почти всё null — применим эвристику для базового заполнения
        non_null = sum(1 for k, v in validated.items() if v not in (None, "", [], {}))
        if non_null <= 2:
            # Сформируем хотя бы базовый анализ из первых 700 символов транскрипта
            base = transcript.strip()
            if len(base) > 700:
                base = base[:700] + "..."
            validated["analysis"] = validated.get("analysis") or base

        # Если analysis не заполнён в parsed — попытка извлечь текстовую часть из raw
        if not validated.get("analysis"):
            # Найти всё до JSON (если JSON найден внутри) — это может быть текстовый анализ
            json_pos = None
            try:
                json_pos = raw.find(json.dumps(parsed))
            except Exception:
                json_pos = None

            if json_pos and json_pos > 0:
                possible_analysis = raw[:json_pos].strip()
            else:
                possible_analysis = raw.strip()

            validated["analysis"] = possible_analysis if possible_analysis else None

        return validated

    except Exception as e:
        log.exception("Ошибка при анализе транскрипта: %s", e)
        # Fallback: простая эвристическая сборка без LLM, чтобы не портить лид ошибками
        basic = _simple_extract(transcript)
        if not basic.get("analysis"):
            # возьмём первые 700 символов для краткого анализа
            base = transcript.strip()
            if len(base) > 700:
                base = base[:700] + "..."
            basic["analysis"] = base
        return basic


def _simple_extract(text: str) -> Dict[str, Any]:
    """Лёгкий оффлайн-экстрактор на regex/эвристиках, без вызова LLM."""
    try:
        import re
        t = (text or "").strip()
        # Имя/фамилия (русские)
        m = re.search(r"\b([А-ЯЁ][а-яё]+)\s+([А-ЯЁ][а-яё]+)\b", t)
        client_name = m.group(1) if m else None
        client_last_name = m.group(2) if m else None
        # Компания (ООО/ИП/АО/ПАО/компания «»)
        company = None
        for p in [r'ООО\s+«([^»]+)»', r'ООО\s+"([^"]+)"', r'ИП\s+([А-ЯЁA-Z][^,\n]+)', r'(?:АО|ПАО|ОАО|ЗАО)\s+«([^»]+)»', r'компания\s+«([^»]+)»']:
            m2 = re.search(p, t)
            if m2:
                company = m2.group(1)
                break
        # Бюджет
        m3 = re.search(r'(\d+[\s\d]*)(?:\s?руб|рублей|₽)', t, flags=re.IGNORECASE)
        ad_budget = m3.group(0) if m3 else None
        # Продукт/услуга: взять первую осмысленную строку, исключая мета-заголовки
        product = None
        for candidate in [seg.strip() for seg in re.split(r'[\n]', t) if seg.strip()]:
            if not _is_header_or_meta(candidate):
                product = candidate[:200]
                break
        # Эвристики по встрече/ЛПР
        is_lpr = True if re.search(r'ЛПР|прин\w* решен', t, re.IGNORECASE) else None
        meeting_scheduled = True if re.search(r'назначим|договорили\w* встреч', t, re.IGNORECASE) else None
        meeting_done = True if re.search(r'встреча прошл', t, re.IGNORECASE) else None

        return {
            "analysis": None,
            "key_request": None,
            "pains_text": None,
            "budget_value": None,
            "budget_currency": None,
            "timeline_text": None,
            "goal_text": None,
            "client_name": client_name,
            "client_last_name": client_last_name,
            "position": None,
            "company_title": company,
            "product": product,
            "task_formulation": None,
            "ad_budget": ad_budget,
            "closing_comment": None,
            "is_lpr": is_lpr,
            "meeting_scheduled": meeting_scheduled,
            "meeting_done": meeting_done,
            "client_type_text": None,
            "bad_reason_text": None,
            "kp_done_text": None,
            "lpr_confirmed_text": None,
            "source_id_code": None,
            "source_id_text": None,
            "source_text": None,
            "our_product_text": None,
            "meeting_date": None,
            "planned_meeting_date": None,
            "meeting_responsible_id": None,
            "sentiment": None,
            "next_action": None,
            "next_action_comment": None,
        }
    except Exception:
        return {"analysis": None}


def create_analysis_summary(data: Dict[str, Any]) -> str:
    """
    Форматирует короткое резюме анализа для отправки в чат.
    """
    if not data:
        return "Анализ недоступен"

    lines = []
    analysis = data.get("analysis") or "Нет анализа"

    lines.append("✅ Анализ встречи выполнен")
    if data.get("is_lpr") is True:
        lines.append("• ЛПР: найден ✅")
    elif data.get("is_lpr") is False:
        lines.append("• ЛПР: не найден ❌")
    else:
        lines.append("• ЛПР: не указано")

    if data.get("meeting_done") is True:
        lines.append("• Встреча: проведена ✅")
    elif data.get("meeting_scheduled") is True:
        lines.append("• Встреча: запланирована ⏳")
    else:
        lines.append("• Встреча: не указано")

    kp = data.get("kp_done_text")
    if kp:
        lines.append(f"• КП: {kp}")

    budget = data.get("ad_budget")
    if budget:
        lines.append(f"• Бюджет: {budget}")

    product = data.get("product")
    if product and not _is_header_or_meta(product):
        prod_short = str(product)[:200] + ("..." if len(str(product)) > 200 else "")
        lines.append(f"• Продукт клиента: {prod_short}")

    lines.append("")
    lines.append("📝 Краткий анализ:")
    lines.append(str(analysis)[:2000])

    return "\n".join(lines)


def get_gemini_info() -> Dict[str, Any]:
    """
    Возвращает информацию о настройках и тестовом ответе Gemini.
    """
    info = {
        "model_name": MODEL_NAME,
        "api_key_present": bool(GEMINI_API_KEY),
        "connection_test": False,
        "max_retries": MAX_RETRIES
    }
    try:
        # Пассивный тест: короткий вызов
        test_prompt = "Короткий ответ: ok"
        resp = _call_gemini(test_prompt, model=MODEL_NAME, max_tokens=16)
        if resp and "ok" in resp.lower():
            info["connection_test"] = True
        else:
            # если получили хоть какой-то ответ, тоже считаем соединение рабочим
            info["connection_test"] = bool(resp)
    except Exception as e:
        log.debug(f"get_gemini_info test failed: {e}")
        info["connection_test"] = False
    return info


def test_gemini_connection() -> bool:
    """
    Утилита для быстрого теста доступности Gemini.
    """
    try:
        return bool(get_gemini_info().get("connection_test"))
    except Exception:
        return False

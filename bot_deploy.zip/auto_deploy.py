#!/usr/bin/env python3
"""
Автоматический деплой бота на сервер
"""

import os
import subprocess
import sys
from pathlib import Path

def get_server_info():
    """Получаем информацию о сервере"""
    print("🔧 Настройка автодеплоя")
    print("=" * 50)
    
    server_ip = input("Введите IP адрес сервера: ").strip()
    username = input("Введите имя пользователя на сервере: ").strip()
    port = input("Введите SSH порт (по умолчанию 22): ").strip() or "22"
    
    return server_ip, username, port

def create_deploy_script(server_ip, username, port):
    """Создаем скрипт для деплоя"""
    
    script_content = f'''#!/bin/bash
# Автоматический деплой бота на сервер

SERVER_IP="{server_ip}"
USERNAME="{username}"
SSH_PORT="{port}"

echo "🚀 Автоматический деплой бота на сервер"
echo "======================================"
echo "Сервер: $USERNAME@$SERVER_IP:$SSH_PORT"
echo ""

# Проверяем SSH ключи
if [ ! -f ~/.ssh/id_rsa ]; then
    echo "🔑 Создаем SSH ключи..."
    ssh-keygen -t rsa -b 4096 -f ~/.ssh/id_rsa -N ""
    echo "📋 Скопируйте публичный ключ на сервер:"
    echo "ssh-copy-id $USERNAME@$SERVER_IP"
    echo "Или добавьте в ~/.ssh/authorized_keys на сервере:"
    cat ~/.ssh/id_rsa.pub
    echo ""
    read -p "Нажмите Enter после настройки SSH ключей..."
fi

# Создаем архив
echo "📦 Создаем архив для деплоя..."
zip -r bot_deploy.zip *.py *.txt *.md *.sh .env requirements.txt

# Загружаем на сервер
echo "⬆️ Загружаем файлы на сервер..."
scp -P $SSH_PORT bot_deploy.zip $USERNAME@$SERVER_IP:~/

# Подключаемся к серверу и запускаем
echo "🔧 Настраиваем бота на сервере..."
ssh -p $SSH_PORT $USERNAME@$SERVER_IP << 'EOF'
    echo "📁 Распаковываем архив..."
    unzip -o bot_deploy.zip
    
    echo "🔧 Устанавливаем зависимости..."
    pip3 install -r requirements.txt
    
    echo "🛑 Останавливаем старые процессы..."
    pkill -f "python.*start_bot" || true
    pkill -f "python.*main" || true
    
    echo "🚀 Запускаем бота..."
    chmod +x quick_start_server.sh
    nohup ./quick_start_server.sh > bot.log 2>&1 &
    
    echo "⏳ Ждем запуска..."
    sleep 5
    
    echo "📋 Проверяем статус..."
    ps aux | grep python | grep -v grep
    
    echo "📄 Последние логи:"
    tail -10 bot.log
    
    echo ""
    echo "✅ Бот запущен на сервере!"
    echo "🧪 Протестируйте: @TranscriptionleadBot"
EOF

echo ""
echo "🎉 ДЕПЛОЙ ЗАВЕРШЕН!"
echo "📱 Протестируйте бота: @TranscriptionleadBot"
'''
    
    with open('auto_deploy.sh', 'w') as f:
        f.write(script_content)
    
    # Делаем скрипт исполняемым
    os.chmod('auto_deploy.sh', 0o755)
    
    print("✅ Скрипт автодеплоя создан: auto_deploy.sh")

def create_windows_deploy():
    """Создаем Windows версию автодеплоя"""
    
    script_content = '''@echo off
echo 🚀 Автоматический деплой бота на сервер
echo ======================================

set /p SERVER_IP="Введите IP адрес сервера: "
set /p USERNAME="Введите имя пользователя на сервере: "
set /p SSH_PORT="Введите SSH порт (по умолчанию 22): "

if "%SSH_PORT%"=="" set SSH_PORT=22

echo.
echo Сервер: %USERNAME%@%SERVER_IP%:%SSH_PORT%
echo.

echo 📦 Создаем архив для деплоя...
powershell -Command "Compress-Archive -Path '*.py', '*.txt', '*.md', '*.sh', '.env', 'requirements.txt' -DestinationPath 'bot_deploy.zip' -Force"

echo ⬆️ Загружаем файлы на сервер...
scp -P %SSH_PORT% bot_deploy.zip %USERNAME%@%SERVER_IP%:~/

echo 🔧 Настраиваем бота на сервере...
ssh -p %SSH_PORT% %USERNAME%@%SERVER_IP% "unzip -o bot_deploy.zip && pip3 install -r requirements.txt && pkill -f 'python.*start_bot' || true && pkill -f 'python.*main' || true && chmod +x quick_start_server.sh && nohup ./quick_start_server.sh > bot.log 2>&1 & && sleep 5 && ps aux | grep python | grep -v grep && tail -10 bot.log"

echo.
echo 🎉 ДЕПЛОЙ ЗАВЕРШЕН!
echo 📱 Протестируйте бота: @TranscriptionleadBot
pause
'''
    
    with open('auto_deploy.bat', 'w') as f:
        f.write(script_content)
    
    print("✅ Windows скрипт автодеплоя создан: auto_deploy.bat")

def main():
    """Основная функция"""
    print("🤖 АВТОМАТИЧЕСКИЙ ДЕПЛОЙ БОТА")
    print("=" * 50)
    
    # Получаем информацию о сервере
    server_ip, username, port = get_server_info()
    
    # Создаем скрипты
    create_deploy_script(server_ip, username, port)
    create_windows_deploy()
    
    print("\n🎯 ГОТОВО!")
    print("Запустите:")
    print("  Windows: auto_deploy.bat")
    print("  Linux/Mac: ./auto_deploy.sh")
    
    # Спрашиваем, запустить ли сейчас
    if input("\nЗапустить автодеплой сейчас? (y/n): ").lower() == 'y':
        if sys.platform == "win32":
            subprocess.run(['auto_deploy.bat'])
        else:
            subprocess.run(['./auto_deploy.sh'])

if __name__ == "__main__":
    main()

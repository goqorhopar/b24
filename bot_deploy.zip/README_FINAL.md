# 🤖 TELEGRAM BOT ДЛЯ АВТОМАТИЗАЦИИ ВСТРЕЧ

## 🎯 НАЗНАЧЕНИЕ
Бот автоматически присоединяется к встречам, записывает аудио, делает транскрипцию, анализирует через Gemini AI и обновляет лиды в Bitrix24.

## ⚠️ КРИТИЧЕСКИ ВАЖНО
**Бот работает ТОЛЬКО на Linux сервере!**
**На Windows бот НЕ БУДЕТ присоединяться к встречам!**

---

## 🚀 БЫСТРЫЙ ЗАПУСК НА СЕРВЕРЕ

### 1. Подключитесь к серверу:
```bash
ssh ваш_пользователь@ваш_сервер_ip
```

### 2. Загрузите файлы бота на сервер

### 3. Запустите бота:
```bash
cd /path/to/bot/folder
chmod +x quick_start_server.sh
./quick_start_server.sh
```

### 4. Проверьте работу:
```bash
tail -f bot.log
```

---

## 🧪 ТЕСТИРОВАНИЕ

1. **Найдите бота:** @TranscriptionleadBot
2. **Отправьте:** `/start`
3. **Отправьте ссылку на встречу**

---

## 📁 ОСНОВНЫЕ ФАЙЛЫ

- `start_bot_fixed.py` - Основной файл запуска бота
- `main.py` - Главная логика бота
- `meeting_link_processor.py` - Обработка встреч
- `aggressive_meeting_automation.py` - Автоматизация браузера
- `speech_transcriber.py` - Транскрипция аудио
- `meeting_analyzer.py` - Анализ через Gemini
- `bitrix.py` - Интеграция с Bitrix24
- `config.py` - Настройки
- `.env` - Переменные окружения

---

## 🔧 НАСТРОЙКА

### Переменные в .env:
```
TELEGRAM_BOT_TOKEN=ваш_токен
GEMINI_API_KEY=ваш_ключ
BITRIX_WEBHOOK_URL=ваш_webhook
ADMIN_CHAT_ID=ваш_chat_id
```

---

## 📋 ФУНКЦИОНАЛ

1. ✅ **Присоединение к встречам** (Zoom, Google Meet, Teams, Kontur.Talk)
2. ✅ **Запись аудио** встречи
3. ✅ **Транскрипция** через Whisper
4. ✅ **Анализ** через Gemini AI с чек-листом
5. ✅ **Отправка результата** в Telegram
6. ✅ **Обновление лидов** в Bitrix24
7. ✅ **Создание задач** в Bitrix24

---

## 🆘 ПОДДЕРЖКА

### Если бот не работает:
1. Проверьте логи: `tail -f bot.log`
2. Проверьте статус: `ps aux | grep python`
3. Перезапустите: `pkill -f python && ./quick_start_server.sh`

### Если бот не присоединяется к встрече:
1. Проверьте Chrome: `google-chrome --version`
2. Проверьте аудио: `pactl list sources`
3. Проверьте права: `ls -la start_bot_fixed.py`

---

## 📞 КОНТАКТЫ

Бот: @TranscriptionleadBot
Логи: `tail -f bot.log`

---

**ПОМНИТЕ: Бот работает ТОЛЬКО на Linux сервере!**
